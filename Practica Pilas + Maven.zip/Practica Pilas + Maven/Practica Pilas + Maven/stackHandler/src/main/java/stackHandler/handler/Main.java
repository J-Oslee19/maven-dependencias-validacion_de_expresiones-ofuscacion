package stackHandler.handler;

import umg.edu.gt.data_structure.stack.impl.SymbolValidator;

public class Main {

    public static void main(String[] args) {

        if (args.length == 0) {
            System.out.println("Debe enviar una expresion como argumento");
            return;
        }

        String expresion = args[0];

        SymbolValidator validator = new SymbolValidator();

        boolean resultado = validator.isBalanced(expresion);

        if (resultado) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
    }
}
