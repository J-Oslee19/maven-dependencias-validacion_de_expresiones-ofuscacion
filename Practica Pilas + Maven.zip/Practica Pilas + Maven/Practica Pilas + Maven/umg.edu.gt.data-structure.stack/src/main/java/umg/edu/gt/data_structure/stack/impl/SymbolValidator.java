package umg.edu.gt.data_structure.stack.impl;

import umg.edu.gt.data_structure.stack.manual.StackLinked;

public class SymbolValidator {

    public boolean isBalanced(String s) {

        StackLinked stack = new StackLinked();

        for (char c : s.toCharArray()) {

            // Si es símbolo de apertura
            if (c == '(' || c == '[' || c == '{') {

                if (stack.isEmpty()) {
                    stack.initStack(c);  // inicializa si está vacía
                } else {
                    stack.push(c);
                }

            // Si es símbolo de cierre
            } else if (c == ')' || c == ']' || c == '}') {

                if (stack.isEmpty()) {
                    return false; // cierre sin apertura
                }

                char top = stack.pop();

                if (!isPair(top, c)) {
                    return false;
                }
            }
        }

        return stack.isEmpty(); // si quedó algo abierto → no está balanceado
    }

    private boolean isPair(char open, char close) {
        return (open == '(' && close == ')')
            || (open == '[' && close == ']')
            || (open == '{' && close == '}');
    }
}